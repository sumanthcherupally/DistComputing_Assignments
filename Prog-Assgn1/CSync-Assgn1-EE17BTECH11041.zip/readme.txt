Compile instructions
	Compile with c++11 or higher version
	Use 
	g++ -std=c++11 -pthread CS-EE17BTECH11041.cpp -o cs